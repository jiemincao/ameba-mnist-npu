#!/bin/bash
echo "Downloading Acuity Toolkit..."
echo
docker pull ghcr.io/ameba-aiot/acuity-toolkit:6.18.8
echo
if [ $? -eq 0 ]; then
    echo "Installation complete!"
    echo "Run: ./run.sh"
else
    echo "Installation failed!"
    echo "Check: Docker is installed and running"
fi