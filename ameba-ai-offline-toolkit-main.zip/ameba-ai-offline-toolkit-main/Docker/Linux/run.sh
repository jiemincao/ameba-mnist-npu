#!/bin/bash

IMAGE_NAME="ghcr.io/ameba-aiot/acuity-toolkit"
IMAGE_TAG="6.18.8"

echo "Starting Acuity Toolkit container..."
echo "Mounting:"
echo "  - $(pwd)/acuity_examples_c901149 -> /workspace/acuity_examples"
echo "  - $(pwd)/Verisilicon_SW_NBInfo_1.2.17_20230412 -> /workspace/Verisilicon_SW_NBInfo_1.2.17_20230412"

docker run -it --rm \
  --user $(id -u):$(id -g) \
  -e HOME=/home/user \
  -w /workspace/acuity_examples \
  -v "$(pwd)/acuity_examples_c901149:/workspace/acuity_examples" \
  -v "$(pwd)/Verisilicon_SW_NBInfo_1.2.17_20230412:/workspace/Verisilicon_SW_NBInfo_1.2.17_20230412" \
  ${IMAGE_NAME}:${IMAGE_TAG}
