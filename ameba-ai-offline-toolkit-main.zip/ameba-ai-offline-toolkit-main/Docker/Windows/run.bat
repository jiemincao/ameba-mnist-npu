@echo off

docker run -it --shm-size=4g --rm ^
  -e HOME=/home/user ^
  -v "%cd%\.docker_home:/home/user" ^
  -w /workspace/acuity_examples ^
  -v "%cd%\acuity_examples_c901149:/workspace/acuity_examples" ^
  -v "%cd%\Verisilicon_SW_NBInfo_1.2.17_20230412:/workspace/Verisilicon_SW_NBInfo" ^
  ghcr.io/ameba-aiot/acuity-toolkit:6.18.8