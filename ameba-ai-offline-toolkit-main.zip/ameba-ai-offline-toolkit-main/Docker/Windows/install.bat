@echo off
echo Downloading Acuity Toolkit...
echo.
docker pull ghcr.io/ameba-aiot/acuity-toolkit:6.18.8
echo.
if %ERRORLEVEL% EQU 0 (
    echo Installation complete!
    echo Run: run.bat
) else (
    echo Installation failed!
    echo Check: Docker Desktop is running
)
pause