# Offline AI Model Conversion Toolkit for Private Users

## Introduction

[Offline AI Model Conversion Toolkit (Acuity Toolkit) Overview](https://ameba-doc-ai-video-analytics-doc.readthedocs-hosted.com/en/latest/user_manual/Acuity_tool/Acuity_overview.html)

## Docker Installation Steps

[Acuity Toolkit Manual Installation](https://ameba-doc-ai-video-analytics-doc.readthedocs-hosted.com/en/latest/user_manual/Acuity_tool/Acuity_installation_docker.html)

## Manual Installation Steps

[Acuity Toolkit Manual Installation](https://ameba-doc-ai-video-analytics-doc.readthedocs-hosted.com/en/latest/user_manual/Acuity_tool/Acuity_installation_manual.html)

## Model Conversion Steps

[NN Model Conversion Steps using Acuity Toolkit on Docker](https://ameba-doc-ai-video-analytics-doc.readthedocs-hosted.com/en/latest/user_manual/Acuity_tool/Acuity_convert_steps.html)

## Quantization Discussion

[Realtek AmebaPro2 NN Quantization Discussion](https://ameba-doc-ai-video-analytics-doc.readthedocs-hosted.com/en/latest/user_manual/NN_quantization_discussion/index.html)
